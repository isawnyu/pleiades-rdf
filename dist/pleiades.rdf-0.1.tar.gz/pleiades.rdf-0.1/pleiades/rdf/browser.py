# RDF browser views

import logging
import geojson
from rdflib import BNode, Literal, Namespace, RDF, URIRef
from rdflib.graph import Graph
from shapely.geometry import asShape, box

from zope.interface import implements, Interface
from zope.publisher.browser import BrowserView

from Products.CMFCore.utils import getToolByName

from pleiades.geographer.geo import IGeoreferenced, location_precision
from pleiades.json.browser import wrap

FOAF_URI = "http://xmlns.com/foaf/0.1/"
FOAF = Namespace(FOAF_URI)

GEO_URI = "http://www.w3.org/2003/01/geo/wgs84_pos#"
GEO = Namespace(GEO_URI)

OSGEO_URI = "http://data.ordnancesurvey.co.uk/ontology/geometry/"
OSGEO = Namespace(OSGEO_URI)

SKOS_URI = "http://www.w3.org/2004/02/skos/core#"
SKOS = Namespace(SKOS_URI)

RDFS_URI = "http://www.w3.org/2000/01/rdf-schema#"
RDFS = Namespace(RDFS_URI)

SPATIAL_URI = "http://geovocab.org/spatial#"
SPATIAL = Namespace(SPATIAL_URI)

OSSPATIAL_URI = "http://data.ordnancesurvey.co.uk/ontology/spatialrelations/"
OSSPATIAL = Namespace(OSSPATIAL_URI)

PLACES = "http://pleiades.stoa.org/places/"

log = logging.getLogger("pleiades.rdf")

class IGraph(Interface):
    def graph():
        """Get a rdflib graph"""

class PlaceGraph(BrowserView):
    implements(IGraph)

    def graph(self):
        catalog = getToolByName(self.context, 'portal_catalog')
        wftool = getToolByName(self.context, 'portal_workflow')

        g = Graph()
        g.bind('rdfs', RDFS)
        g.bind('skos', SKOS)
        g.bind('spatial', SPATIAL)
        g.bind('geo', GEO)
        g.bind('foaf', FOAF)
        g.bind('osgeo', OSGEO)
        g.bind('osspatial', OSSPATIAL)

        context_page = PLACES + self.context.getId()
        context_subj = URIRef(context_page + "#this")
        
        # Type
        g.add((context_subj, RDF.type, SPATIAL['Feature']))

        # primary topic
        g.add((
            context_subj,
            FOAF['primaryTopicOf'],
            URIRef(context_page)))

        # title as rdfs:label
        g.add((
            context_subj,
            RDFS['label'], 
            Literal(unicode(self.context.Title(), 'utf-8'))))

        # description as rdfs:comment
        g.add((
            context_subj,
            RDFS['comment'], 
            Literal(unicode(self.context.Description(), 'utf-8'))))

        # Names as skos:label and prefLabel
        folder_path = "/".join(self.context.getPhysicalPath())
        brains = catalog(
            path={'query': folder_path, 'depth': 1}, 
            portal_type='Name', 
            review_state='published')
        objs = [b.getObject() for b in brains]
        name_ratings = [
            catalog.getIndexDataForRID(
                b.getRID())['average_rating'] for b in brains]
        rated_names = sorted(
            zip(
                name_ratings, 
                [o.getNameAttested() or o.getNameTransliterated() for o in objs]),
            reverse=True)
        
        for rating, name in rated_names[:1]:
            g.add((
                context_subj,
                SKOS['prefLabel'], 
                Literal(name)))
        
        for rating, name in rated_names[1:]:
            g.add((
                context_subj,
                SKOS['altLabel'], 
                Literal(name)))
        
        ## representative point
        xs = []
        ys = []
        folder_path = "/".join(self.context.getPhysicalPath())
        brains = catalog(
            path={'query': folder_path, 'depth': 1}, 
            portal_type='Location', 
            review_state='published')
        locs = [b.getObject() for b in brains]
        location_ratings = [
            catalog.getIndexDataForRID(
                b.getRID())['average_rating'] for b in brains]
        features = [wrap(ob, 0) for ob in locs]

        # get representative point
        loc_prec = location_precision(self.context)
        if loc_prec == 'precise':
            repr_point = None
            for r, f in sorted(zip(location_ratings, features), reverse=True):
                if f.geometry and hasattr(f.geometry, '__geo_interface__'):
                    shape = asShape(f.geometry)
                    b = shape.bounds
                    xs.extend([b[0], b[2]])
                    ys.extend([b[1], b[3]])
                    if repr_point is None and r and r[0] > 0.0:
                        repr_point = shape.centroid
            if len(xs) * len(ys) > 0:
                bbox = [min(xs), min(ys), max(xs), max(ys)]
            else:
                bbox = None
        
            if repr_point:
                g.add((
                    context_subj,
                    GEO['lat'],
                    Literal(repr_point.y)))
                g.add((
                    context_subj,
                    GEO['long'],
                    Literal(repr_point.x)))
        elif loc_prec == 'rough':
            for loc in locs:
                ref = loc.getLocation()
                if ref and ref.startswith('http://atlantides.org/capgrids'):
                    bounds = box(*IGeoreferenced(loc).bounds)
                    g.add((
                        context_subj,
                        OSSPATIAL['within'],
                        URIRef(ref)))
                    b = BNode() # the grid's extent
                    g.add((b, RDF.type, OSGEO['AbstractGeometry']))
                    g.add((
                        URIRef(ref),
                        OSGEO['extent'],
                        b))
                    g.add((
                        b,
                        OSGEO['asGeoJSON'],
                        Literal(geojson.dumps(bounds.__geo_interface__))))

        # connects with
        for f in (
            self.context.getConnections() + self.context.getConnections_from()):
            if wftool.getInfoFor(f, 'review_state') != 'published':
                continue
            feature_obj = URIRef(PLACES + f.getId() + "#this")
            g.add((context_subj, SPATIAL['C'], feature_obj))

        # seeAlso
        for c in self.context.getReferenceCitations():
            if c.get('identifier'):
                g.add((context_subj, RDFS['seeAlso'], URIRef(c.get('identifier'))))

        return g

    def __call__(self):
        self.request.response.setStatus(200)
        self.request.response.setHeader('Content-Type', "text/n3; charset=utf-8")
        return self.graph().serialize(format='n3')

